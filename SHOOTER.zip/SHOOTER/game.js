const canvas = document.getElementById("game")
const ctx = canvas.getContext("2d")

let gameState = "menu"
let score = 0

let keys = {}

document.addEventListener("keydown",e=>keys[e.key]=true)
document.addEventListener("keyup",e=>keys[e.key]=false)

const playerImages=[new Image(),new Image(),new Image()]
playerImages[0].src="images/player1.png"
playerImages[1].src="images/player2.png"
playerImages[2].src="images/player3.png"

const enemyImg=new Image()
enemyImg.src="images/enemy.png"

const bossImg=new Image()
bossImg.src="images/boss.png"

const bg=new Image()
bg.src="images/background.png"

let player={
    x:420,
    y:380,
    w:60,
    h:60,
    speed:6,
    hp:100,
    img:null
}

let bullets=[]
let enemies=[]
let boss=null
let bossBullets=[]
let explosions=[]

let bossSpawned=false

canvas.addEventListener("click",e=>{

    if(gameState==="menu"){

        let x=e.offsetX
        let y=e.offsetY

        if(x>200 && x<260 && y>200 && y<260) startGame(0)
        if(x>400 && x<460 && y>200 && y<260) startGame(1)
        if(x>600 && x<660 && y>200 && y<260) startGame(2)

    }

})

function startGame(i){

    player.img=playerImages[i]
    gameState="game"

}

document.addEventListener("keydown",e=>{

    if(e.key===" " && gameState==="game"){

        bullets.push({
            x:player.x+25,
            y:player.y,
            w:8,
            h:20
        })

    }

})

function spawnEnemy(){

    if(gameState!=="game") return

    enemies.push({
        x:Math.random()*850,
        y:-40,
        w:40,
        h:40,
        speed:2
    })

}

setInterval(spawnEnemy,1200)

function spawnBoss(){

    boss={
        x:350,
        y:80,
        w:200,
        h:120,
        hp:200,
        speed:3,
        direction:1,
        moveTimer:0
    }

}

function bossShoot(){

    if(!boss) return

    bossBullets.push({
        x:boss.x+boss.w/2,
        y:boss.y+boss.h,
        w:10,
        h:20,
        speed:6
    })

}

setInterval(()=>{

    if(gameState==="game" && boss){
        bossShoot()
    }

},1500)

function createExplosion(x,y){

    explosions.push({
        x:x,
        y:y,
        radius:10,
        life:20
    })

}

function update(){

    if(gameState!=="game") return

    if(keys["ArrowLeft"]) player.x-=player.speed
    if(keys["ArrowRight"]) player.x+=player.speed

    bullets.forEach(b=>b.y-=10)

    enemies.forEach(e=>e.y+=e.speed)

    bossBullets.forEach(b=>b.y+=b.speed)

    if(score>20 && !bossSpawned){
        spawnBoss()
        bossSpawned=true
    }

    if(boss){

        boss.moveTimer--

        if(boss.moveTimer<=0){
            boss.direction=Math.random()>0.5?1:-1
            boss.moveTimer=60
        }

        boss.x+=boss.speed*boss.direction

        if(boss.x<0 || boss.x+boss.w>canvas.width){
            boss.direction*=-1
        }

    }

    bullets.forEach((b,bi)=>{

        enemies.forEach((e,ei)=>{

            if(
                b.x<e.x+e.w &&
                b.x+b.w>e.x &&
                b.y<e.y+e.h &&
                b.y+b.h>e.y
            ){

                createExplosion(e.x+20,e.y+20)

                bullets.splice(bi,1)
                enemies.splice(ei,1)
                score++

            }

        })

        if(boss){

            if(
                b.x<boss.x+boss.w &&
                b.x+b.w>boss.x &&
                b.y<boss.y+boss.h &&
                b.y+b.h>boss.y
            ){

                bullets.splice(bi,1)
                boss.hp-=10

                if(boss.hp<=0){

                    for(let i=0;i<10;i++){
                        createExplosion(
                            boss.x+Math.random()*200,
                            boss.y+Math.random()*100
                        )
                    }

                    score+=50
                    boss=null
                    gameState="win"

                }

            }

        }

    })

    bossBullets.forEach((b,i)=>{

        if(
            b.x<player.x+player.w &&
            b.x+b.w>player.x &&
            b.y<player.y+player.h &&
            b.y+b.h>player.y
        ){

            player.hp-=10
            bossBullets.splice(i,1)

        }

    })

    explosions.forEach((ex,i)=>{

        ex.radius+=2
        ex.life--

        if(ex.life<=0){
            explosions.splice(i,1)
        }

    })

}

function drawMenu(){

    ctx.fillStyle="white"
    ctx.font="40px Arial"
    ctx.fillText("CHỌN NHÂN VẬT",320,120)

    ctx.drawImage(playerImages[0],200,200,60,60)
    ctx.drawImage(playerImages[1],400,200,60,60)
    ctx.drawImage(playerImages[2],600,200,60,60)

    ctx.font="20px Arial"
    ctx.fillText("Click nhân vật để chọn",360,320)

}

function drawGame(){

    ctx.drawImage(bg,0,0,900,500)

    ctx.drawImage(player.img,player.x,player.y,player.w,player.h)

    bullets.forEach(b=>{
        ctx.fillStyle="yellow"
        ctx.fillRect(b.x,b.y,b.w,b.h)
    })

    bossBullets.forEach(b=>{
        ctx.fillStyle="purple"
        ctx.fillRect(b.x,b.y,b.w,b.h)
    })

    enemies.forEach(e=>{
        ctx.drawImage(enemyImg,e.x,e.y,e.w,e.h)
    })

    if(boss){

        ctx.drawImage(bossImg,boss.x,boss.y,boss.w,boss.h)

        ctx.fillStyle="red"
        ctx.fillRect(300,20,boss.hp*2,20)

    }

    explosions.forEach(ex=>{

        ctx.beginPath()
        ctx.arc(ex.x,ex.y,ex.radius,0,Math.PI*2)
        ctx.fillStyle="orange"
        ctx.fill()

    })

    ctx.fillStyle="white"
    ctx.font="20px Arial"
    ctx.fillText("Score: "+score,20,30)

    ctx.fillText("HP: "+player.hp,20,60)

}

function drawWin(){

    ctx.fillStyle="white"
    ctx.font="60px Arial"
    ctx.fillText("YOU WIN!",330,220)

    ctx.font="30px Arial"
    ctx.fillText("Final Score: "+score,350,280)

}

function draw(){

    ctx.clearRect(0,0,900,500)

    if(gameState==="menu") drawMenu()

    if(gameState==="game") drawGame()

    if(gameState==="win") drawWin()

}

function gameLoop(){

    update()
    draw()

    requestAnimationFrame(gameLoop)

}

gameLoop()